first=5
second=4
summa=first + second
print("summa =", summa)
diff=first - second
print("diff =", diff)