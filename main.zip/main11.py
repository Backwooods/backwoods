first=5
second=10
third=15
mean=(first+second+third) / 3
print(mean)