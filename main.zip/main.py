a='Hello'
print(len(a))