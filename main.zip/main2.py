first_string='Понедельник'
second_string='Вторник'
print(first_string + ', ' + second_string)